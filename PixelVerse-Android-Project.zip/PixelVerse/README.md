# PixelVerse Android prototype

A starter native Android app built with Kotlin and Jetpack Compose. It includes a home screen, a playable tap counter mini-game, a world-name editor preview, a claimable coin reward, and a profile screen.

## Open and run
1. Install Android Studio (recent stable version).
2. Open this `PixelVerse` folder as a project.
3. Allow Gradle to sync and install any requested Android SDK components (compile SDK 35).
4. Run the `app` configuration on an Android emulator or connected Android phone.

## Notes
- This is a starter project, not a signed APK. Android Studio builds and installs it.
- Tap Blitz and the reward counter are interactive. World Creator is currently a visual prototype; it does not generate or save a real 3D world yet.
- No account, network connection, or permissions are required.
