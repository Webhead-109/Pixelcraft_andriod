package com.example.pixelverse

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF070B18)
private val Panel = Color(0xFF111A2D)
private val Cyan = Color(0xFF22D3EE)
private val Purple = Color(0xFF9B5CFF)
private val Green = Color(0xFF35E58A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PixelVerseApp() }
    }
}

@Composable
fun PixelVerseApp() {
    var page by remember { mutableStateOf("Home") }
    var taps by remember { mutableIntStateOf(0) }
    var coins by remember { mutableIntStateOf(320) }
    var worldName by remember { mutableStateOf("My First World") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color(0xFF0C1222), contentColor = Cyan) {
                listOf("Home", "Games", "Create", "Rewards", "Profile").forEach { item ->
                    val icon = when(item) { "Home" -> Icons.Default.Home; "Games" -> Icons.Default.SportsEsports; "Create" -> Icons.Default.AutoFixHigh; "Rewards" -> Icons.Default.CardGiftcard; else -> Icons.Default.Person }
                    NavigationBarItem(selected = page == item, onClick = { page = item }, icon = { Icon(icon, contentDescription = item) }, label = { Text(item, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, indicatorColor = Color(0xFF17354A), unselectedIconColor = Color.LightGray, unselectedTextColor = Color.LightGray))
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Bg)) {
                when(page) {
                    "Home" -> HomeScreen(coins, onPlay = { page = "Games" }, onCreate = { page = "Create" })
                    "Games" -> GamesScreen(taps = taps, onTap = { taps++; if (taps % 10 == 0) coins += 5 })
                    "Create" -> CreateScreen(worldName, { worldName = it })
                    "Rewards" -> RewardsScreen(coins, onClaim = { coins += 25 })
                    else -> ProfileScreen(coins, taps)
                }
            }
        }
    }
}

@Composable fun Header(eyebrow: String, title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp)) {
        Text(eyebrow.uppercase(), color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Text(title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text(subtitle, color = Color(0xFFB5C3DA), fontSize = 14.sp)
    }
}

@Composable fun HomeScreen(coins: Int, onPlay: () -> Unit, onCreate: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(bottom = 18.dp)) {
        item { Header("Your universe starts here", "PixelVerse ✦", "Play. Create. Explore.") }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(listOf(Color(0xFF152C62), Color(0xFF34165C), Color(0xFF102A42)))).padding(22.dp)) {
                Text("🪐", fontSize = 58.sp)
                Text("WELCOME, CREATOR", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp)
                Text("Make today\nlegendary.", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 36.sp)
                Spacer(Modifier.height(8.dp)); Text("Jump into quick challenges or dream up your own pixel world.", color = Color(0xFFDCE6FF), fontSize = 14.sp)
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color(0xFF062015)), modifier = Modifier.weight(1f)) { Icon(Icons.Default.PlayArrow, null); Text(" Play", fontWeight = FontWeight.Bold) }
                    OutlinedButton(onClick = onCreate, modifier = Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Icon(Icons.Default.AutoFixHigh, null); Text(" Create") }
                }
            }
        }
        item { Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("🪙", "Your coins", coins.toString(), Modifier.weight(1f)); StatCard("⚡", "Daily streak", "3 days", Modifier.weight(1f)); StatCard("🏆", "Level", "Level 4", Modifier.weight(1f))
        } }
        item { Text("PICK YOUR NEXT ADVENTURE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 1.sp, modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 10.dp)) }
        item { FeatureRow("🎯", "Tap Blitz", "Fast fingers, big scores", "PLAY", onPlay) }
        item { FeatureRow("🌄", "World Creator", "Build a world of your own", "BUILD", onCreate) }
        item { FeatureRow("🎁", "Daily Drop", "Grab a little bonus", "CLAIM", onCreate) }
    }
}

@Composable fun StatCard(emoji: String, label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(Panel).padding(12.dp)) { Text(emoji, fontSize = 22.sp); Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp); Text(label, color = Color(0xFF9EACC6), fontSize = 10.sp) }
}

@Composable fun FeatureRow(emoji: String, title: String, subtitle: String, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clip(RoundedCornerShape(16.dp)).background(Panel).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 28.sp); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.Bold); Text(subtitle, color = Color(0xFF9EACC6), fontSize = 12.sp) }
        Text(action, color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable fun GamesScreen(taps: Int, onTap: () -> Unit) {
    Header("Mini-game arcade", "Tap Blitz ⚡", "Tap the glowing orb as many times as you can!")
    Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { StatCard("👆", "Total taps", taps.toString()); StatCard("🔥", "Best streak", (taps / 10).toString()); StatCard("🪙", "Bonus", "+5 / 10 taps") }
        Spacer(Modifier.height(28.dp))
        Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(28.dp)).background(Brush.radialGradient(listOf(Color(0xFF263D77), Color(0xFF12152F), Bg))), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("TAP TO SCORE", color = Cyan, fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(20.dp))
                Box(Modifier.size(180.dp).clip(RoundedCornerShape(90.dp)).background(Brush.linearGradient(listOf(Purple, Cyan, Color(0xFF246BFF)))).clickable { onTap() }, contentAlignment = Alignment.Center) { Text("✦", fontSize = 84.sp, color = Color.White) }
                Spacer(Modifier.height(24.dp)); Text("$taps", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.ExtraBold); Text("TAPS SCORED", color = Color(0xFF9EACC6), fontSize = 11.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(22.dp)); Text("Every 10 taps earns 5 bonus coins 🪙", color = Color(0xFFD4DDF1), textAlign = TextAlign.Center, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(16.dp)); Text("No timer, just vibes. Keep tapping!", color = Color(0xFF9EACC6), fontSize = 12.sp)
    }
}

@Composable fun CreateScreen(worldName: String, onNameChange: (String) -> Unit) {
    Header("Creator studio", "Build your world 🌄", "Give your next masterpiece a name.")
    Column(Modifier.fillMaxWidth().padding(18.dp).clip(RoundedCornerShape(24.dp)).background(Panel).padding(20.dp)) {
        Box(Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Color(0xFF1C6B72), Color(0xFF23457D), Color(0xFF42246F)))), contentAlignment = Alignment.Center) { Text("🌳   🏔️\n\n🏡  🌊  ✨", fontSize = 34.sp, textAlign = TextAlign.Center, lineHeight = 40.sp) }
        Spacer(Modifier.height(18.dp)); Text("WORLD NAME", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(8.dp)); OutlinedTextField(value = worldName, onValueChange = onNameChange, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Name your world") }, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF45516B), focusedLabelColor = Cyan, unfocusedLabelColor = Color.LightGray))
        Spacer(Modifier.height(14.dp)); Text("STARTING BIOME", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(10.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("🌲 Forest", "🏜️ Desert", "❄️ Snow").forEach { label -> Surface(color = Color(0xFF202B46), shape = RoundedCornerShape(12.dp)) { Text(label, color = Color.White, modifier = Modifier.padding(horizontal = 10.dp, vertical = 12.dp), fontSize = 12.sp) } } }
        Spacer(Modifier.height(18.dp)); Button(onClick = { }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Icon(Icons.Default.Check, null); Text("  Save World") }
        Text("Prototype preview: world building is a concept feature.", color = Color(0xFF9EACC6), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable fun RewardsScreen(coins: Int, onClaim: () -> Unit) {
    Header("Loot time", "Daily rewards 🎁", "A little bonus for showing up.")
    Column(Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xFF3A2368), Color(0xFF172B52)))).padding(22.dp)) {
        Text("TODAY'S DROP", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 2.sp); Text("🪙", fontSize = 58.sp); Text("25 bonus coins", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 25.sp); Text("Use your coins to flex your future style.", color = Color(0xFFD4DDF1), fontSize = 13.sp); Spacer(Modifier.height(16.dp)); Button(onClick = onClaim, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color(0xFF062015))) { Text("Claim +25 coins", fontWeight = FontWeight.Bold) }
    }
    Spacer(Modifier.height(16.dp)); Text("YOUR WALLET", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp)); Text("🪙  $coins coins", color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(20.dp))
    FeatureRow("✨", "Glow Trail", "A shiny trail for your profile", "150 🪙", {})
    FeatureRow("🛸", "Cosmic Badge", "Show off your space vibes", "250 🪙", {})
}

@Composable fun ProfileScreen(coins: Int, taps: Int) {
    Header("Player card", "Creator profile 😎", "Your little corner of PixelVerse.")
    Column(Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(24.dp)).background(Panel).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(100.dp).clip(RoundedCornerShape(50.dp)).background(Brush.linearGradient(listOf(Cyan, Purple))), contentAlignment = Alignment.Center) { Text("👾", fontSize = 48.sp) }
        Spacer(Modifier.height(12.dp)); Text("Pixel Explorer", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold); Text("Level 4 • Cosmic Rookie", color = Cyan, fontSize = 13.sp)
        Spacer(Modifier.height(22.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(taps.toString(), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Total taps", color = Color(0xFF9EACC6), fontSize = 11.sp) }; Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(coins.toString(), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Coins", color = Color(0xFF9EACC6), fontSize = 11.sp) }; Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("1", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Worlds", color = Color(0xFF9EACC6), fontSize = 11.sp) } }
    }
    Spacer(Modifier.height(14.dp)); FeatureRow("🏆", "Achievements", "Keep playing to unlock milestones", "VIEW", {})
}
